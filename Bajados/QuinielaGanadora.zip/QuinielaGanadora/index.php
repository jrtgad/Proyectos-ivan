<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="stylesheet.css" />
        <title>Equipos</title>
    </head>
    <body>
        <h1>Formulario de Recogida de equipos</h1>

        <?php
        $mensaje = '';
        if (isset($_GET['mensaje']))
            $mensaje = $_GET['mensaje'];

        echo "<h1>$mensaje</h1>"
        ?>
        <div class="info">
            <form action ="crearformquiniela.php" method="POST">
                <label for="equipos">Lista de Equipos</label>
                <input type="text" id="equipos"
                       pattern="([a-zA-Z\s\d])+([,][a-zA-Z\s\d]+)*" 
                       required
                       name="equipos" />

                <button type="submit" name="recequipos">Generar</button>
            </form>
        </div>
    </body>
</html>
