<?php
//Intento de acceso directo
if (!isset($_POST)) {
    header("Location: index.php");
}

$quiniela = $_POST['quiniela'];
$aciertos = 0;

// Generarión aleatoria de los goles del partido y determinación del resultado (1, x, 2) correspondiente
for ($i = 0; $i < count($quiniela); $i++) {
    $quiniela[$i]['golLoc'] = mt_rand(0, 5);
    $quiniela[$i]['golVis'] = mt_rand(0, 5);
    if ($quiniela[$i]['golLoc'] > $quiniela[$i]['golVis']) {
        $quiniela[$i]['apuestaOK'] = '1';
    } else if ($quiniela[$i]['golLoc'] < $quiniela[$i]['golVis']) {
        $quiniela[$i]['apuestaOK'] = '2';
    } else
        $quiniela[$i]['apuestaOK'] = 'X';

    if ($quiniela[$i]['apuesta'] === $quiniela[$i]['apuestaOK'])
        $aciertos++;
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="stylesheet.css" />
        <title>Muestra Quiniela Ganadora</title>
    </head>
    <body>

        <h1>Quiniela Ganadora</h1>       
<?php
echo "<table>";
echo "<tr>";
echo "<td>Equipo Local</td><td>Gol Local</td><td>Equipo Visitante</td><td>Gol Visitante</td><td>Ap.Jugador</td><td>Ap. Correcta</td>";
echo "</tr>";
foreach ($quiniela as $partido) {
    echo "<tr>";
    echo "<td>{$partido['eqLoc']}</td>";
    echo "<td>{$partido['golLoc']}</td>";
    echo "<td>{$partido['eqVis']}</td>";
    echo "<td>{$partido['golVis']}</td>";
    echo "<td>{$partido['apuesta']}</td>";
    echo "<td>{$partido['apuestaOK']}</td>";
}
echo "</tr>";
echo "</table>";
echo "<p>Número de aciertos $aciertos</p>"
?>
    </body>
</html>

