<?php
//Intento de acceso directo
if (!isset($_POST)) {
    header("Location: index.php");
}


$equipos = $_POST['equipos'];
//Extraigo los nombres de los equipos, elminando los posibles blancos antes y despues de la 
//coma y elimino duplicados
$equipos = array_unique(
        array_map(
                "trim", explode(',', $equipos)));

//Compruebo que se hayan pasado al menos dos equipos
if (count($equipos) < 2) {
    header("Location: index.php?mensaje='Introduzca al menos dos equipos'");
}

shuffle($equipos);
$jornada = array_chunk($equipos, 2);
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="stylesheet.css" />
        <title>Introduce Apuesta</title>
    </head>
    <body>

        <h1>Realiza tu apuesta</h1>

        <form action="procesaquiniela.php" method="POST">
               
                    <?php
                    echo "<table>";
                    echo "<tr>";
                    echo "<td>EquipoCasa</td><td>EquipoVisitante</td><td>Apuesta</td>";
                    echo "</tr>";
                    $numpartidos = round(count($equipos)/2);
                    for ($i = 0; $i < $numpartidos; $i++) {
                        echo "<tr>";
                        echo "<td>{$jornada[$i][0]}</td>";
                        echo "<td>{$jornada[$i][1]}</td>";
                        echo "<td><input type='hidden' value='{$jornada[$i][0]}' name='quiniela[$i][eqLoc]'></td>";
                        echo "<td><input type='hidden' value='{$jornada[$i][1]}' name='quiniela[$i][eqVis]'></td>"; 
                        echo "<td> <select name = 'quiniela[$i][apuesta]'>
                                <option>1</option>
                                <option>X</option>
                                <option>2</option>
                                </select> </td>"; 
              
                    echo "</tr>";
                    }
                    echo "</table>";
                    ?>
              
            <button type="submit" name="submit">Comprobar</button>
        </form>
    </body>
</html>
