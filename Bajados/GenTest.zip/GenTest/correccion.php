<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // Compruebo que no me invocan directamente desde la URL
        if (!isset($_POST))
            header("Location: index.php");

        // Fórmula para calcular la respuesta correcta
        function calcRespuestaCorrecta($p) {
            return ($p % 4) + 1;
        }

        // Leo los valores del formulario
        $test = $_POST['test'];
        $respuestasCorrectas = 0;
        // Se corrigen las respuestas
        foreach ($test as $pregunta => $respuesta) {
            if (calcRespuestaCorrecta($pregunta) == $respuesta) {
                $respuestasCorrectas++;
            }
        }
        // Se muestra la nota el usuario
        echo "<h1>Tu nota es: " . $respuestasCorrectas * 2 . "</h1>";
        ?>
    </body>
</html>
