<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // Utilizo las constantes para simplificar los cambios en caso de
        // necesitar variar dichos parámetros
        define("NUM_PREGUNTAS_BATERIA", 20);
        define("NUM_PREGUNTAS_TEST", 5);
        define("NUM_RESPUESTAS", 4);
        // Genero un array de cinco números aleatorios del 1 al 20
        $preguntas = range(1, NUM_PREGUNTAS_BATERIA);
        shuffle($preguntas);
        $test = array_slice($preguntas, 0, 5);
        ?>
        <!-- Genero la página que contiene el test -->
        <form name='form-test' action='correccion.php' method='POST'>    
            <?php
            echo "<h3>Responde al siguiente test:</h3>";
            echo "<ol>";
            for ($i = 0; $i < NUM_PREGUNTAS_TEST; $i++) {
                echo "<li>Pregunta-$test[$i]</li>";
                echo "<ol>";
                for ($j = 1; $j <= NUM_RESPUESTAS; $j++) {
                    // Utilizo un array simple cuyo indice es el numero de la pregunta
                    // y el valor es la respuesta del usuario
                    echo "<li>Respuesta-$j <input type='radio' name=test[$test[$i]] value='$j'/></li>";
                }
                echo "</ol>";
            }
            echo "</ol>";
            ?>
            <input type="submit" value="Corregir" name="enviar" />
        </form>
    </body>
</html>

